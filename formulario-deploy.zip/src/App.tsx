import React from 'react';
import FormularioPresentes from './components/FormularioPresentes';
import './App.css';

function App() {
  return (
    <div className="App">
      <FormularioPresentes />
    </div>
  );
}

export default App;
